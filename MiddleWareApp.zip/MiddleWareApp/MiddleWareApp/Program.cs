var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// User Story 1 & 2: Custom Logging Middleware
app.Use(async (context, next) =>
{
    // Log Request
    Console.WriteLine($"Incoming Request: {context.Request.Method} {context.Request.Path}");
    await next();
    // Log Response
    Console.WriteLine($"Outgoing Response: {context.Response.StatusCode}");
});

// User Story 4: Basic Security (CSP Header)
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("Content-Security-Policy", "default-src 'self';");
    await next();
});

app.UseHttpsRedirection(); // Enforce HTTPS
app.UseStaticFiles();      // User Story 3: Serve files from wwwroot

app.MapGet("/", () => "Middleware is active. Visit /index.html");

app.Run();