﻿console.log("Middleware Application: script.js has been loaded.");

function checkStatus() {
    const text = document.getElementById("status-text");
    text.innerText = "Success! JavaScript is working and interacting with the DOM.";
    text.style.color = "green";
    text.style.fontWeight = "bold";

    alert("Middleware is successfully serving this JS file!");
}