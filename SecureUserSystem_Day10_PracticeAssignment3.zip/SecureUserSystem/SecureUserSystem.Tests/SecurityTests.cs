﻿using Xunit;
using SecureUserSystem;

namespace SecureUserSystem.Tests
{
    public class SecurityTests
    {
        [Fact]
        public void Password_ShouldBeHashed()
        {
            var service = new UserService();
            string pass = "12345";
            string hashed = service.HashPassword(pass);

            Assert.NotEqual(pass, hashed);
        }

        [Fact]
        public void Encryption_ShouldBeReversible()
        {
            var service = new UserService();
            string original = "SensitiveInfo";
            string encrypted = service.EncryptData(original);
            string decrypted = service.DecryptData(encrypted);

            Assert.Equal(original, decrypted);
        }
    }
}