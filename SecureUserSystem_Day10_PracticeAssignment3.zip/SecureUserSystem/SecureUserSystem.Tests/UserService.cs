﻿namespace SecureUserSystem.Tests
{
    internal class UserService
    {
        public UserService()
        {
        }

        internal string DecryptData(string encrypted)
        {
            throw new NotImplementedException();
        }

        internal string EncryptData(string original)
        {
            throw new NotImplementedException();
        }

        internal string HashPassword(string pass)
        {
            throw new NotImplementedException();
        }
    }
}