﻿using System;
using System.Security.Cryptography;
using System.Text;
using Serilog;

namespace SecureUserSystem
{
    // Task 1: User Model
    public class User
    {
        public string Username { get; set; }
        public string HashedPassword { get; set; }
        public string EncryptedDetails { get; set; }
    }

    public class UserService
    {
        // AES Configuration (Task 2)
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890123456"); // Must be 16 bytes
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("8765432109876543");

        // Task 1 & 2: Hash password using SHA-256
        public string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        // Task 2: Encrypt Sensitive Data
        public string EncryptData(string plainText)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                using (var ms = new System.IO.MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (var sw = new System.IO.StreamWriter(cs)) { sw.Write(plainText); }
                        return Convert.ToBase64String(ms.ToArray());
                    }
                }
            }
        }

        // Task 2: Decrypt Sensitive Data
        public string DecryptData(string cipherText)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                using (var ms = new System.IO.MemoryStream(Convert.FromBase64String(cipherText)))
                {
                    using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (var sr = new System.IO.StreamReader(cs)) { return sr.ReadToEnd(); }
                    }
                }
            }
        }

        // Task 1 & 3: Authentication with Logging
        public bool Authenticate(User user, string inputPassword)
        {
            try
            {
                string hashedInput = HashPassword(inputPassword);
                if (user.HashedPassword == hashedInput)
                {
                    Log.Information("User {Username} authenticated successfully.", user.Username);
                    return true;
                }
                Log.Warning("Failed login attempt for {Username}.", user.Username);
                return false;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error during authentication for {Username}", user.Username);
                return false;
            }
        }
    }
}