﻿using System;
using Serilog;
using SecureUserSystem;

// Task 3: Setup Logging
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/app_log.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

UserService userService = new UserService();
User registeredUser = null;

Console.WriteLine("=== Secure .NET User Management System ===");

try
{
    // --- STEP 1: REGISTRATION ---
    Console.WriteLine("\n[1] Register New User");
    Console.Write("Enter a new username: ");
    string regName = Console.ReadLine();

    Console.Write("Enter a new password: ");
    string regPass = Console.ReadLine();

    Console.Write("Enter sensitive detail (e.g., Home Address): ");
    string sensitiveInfo = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(regName) || string.IsNullOrWhiteSpace(regPass))
    {
        throw new ArgumentException("Username and Password cannot be empty.");
    }

    // Creating the user (Hashing password and Encrypting details)
    registeredUser = new User
    {
        Username = regName,
        HashedPassword = userService.HashPassword(regPass),
        EncryptedDetails = userService.EncryptData(sensitiveInfo)
    };

    Log.Information("New user registered: {Username}", regName);
    Console.WriteLine("\nRegistration Successful!");
    Console.WriteLine($"Stored Hashed Password: {registeredUser.HashedPassword}");

    // --- STEP 2: LOGIN ---
    Console.WriteLine("\n[2] Login to Account");
    Console.Write("Username: ");
    string loginName = Console.ReadLine();

    Console.Write("Password: ");
    string loginPass = Console.ReadLine();

    if (loginName == registeredUser.Username && userService.Authenticate(registeredUser, loginPass))
    {
        Console.WriteLine("\nAccess Granted!");

        // Task 2: Demonstrate Decryption
        string decrypted = userService.DecryptData(registeredUser.EncryptedDetails);
        Console.WriteLine($"Your Decrypted Secret: {decrypted}");
    }
    else
    {
        Console.WriteLine("\nAccess Denied: Invalid username or password.");
    }
}
// Task 3: Proper Error Handling
catch (ArgumentException ex)
{
    Console.WriteLine($"Input Error: {ex.Message}");
    Log.Warning("User provided invalid input: {Message}", ex.Message);
}
catch (Exception ex)
{
    Console.WriteLine("A system error occurred. Please check logs.");
    Log.Error(ex, "Unexpected application error.");
}
finally
{
    Log.Information("Application shutting down.");
    Log.CloseAndFlush();
    Console.WriteLine("\nPress any key to exit...");
    Console.ReadKey();
}