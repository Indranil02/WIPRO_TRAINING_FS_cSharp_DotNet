namespace ProductApp.Models
{
    public class Category
    {
        public int CategoryID { get; set; }
        public required string Name { get; set; }
    }

    public class Product
    {
        public int ProductID { get; set; }
        public required string Name { get; set; }
        public required string Description { get; set; }
        // Collection for complex model binding
        public List<Category> Categories { get; set; } = new List<Category>();
    }
}