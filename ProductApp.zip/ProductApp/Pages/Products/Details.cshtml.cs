using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductApp.Models; // Access your Product model
using System.Linq;

namespace ProductApp.Pages.Products
{
    public class DetailsModel : PageModel
    {
        public Product? Product { get; set; }

        // This 'id' parameter receives the value from the custom route /Products/{id}
        public void OnGet(int id)
        {
            // Find the product in the static list we created in Index.cshtml.cs
            Product = IndexModel.Products.FirstOrDefault(p => p.ProductID == id);
        }
    }
}