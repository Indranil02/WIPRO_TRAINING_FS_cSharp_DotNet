using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductApp.Models; // This tells the file where to find your Product class

namespace ProductApp.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public required Product NewProduct { get; set; }

        // Static list to persist data in memory for this assignment
        public static List<Product> Products { get; set; } = new List<Product>();

        public void OnGet()
        {
            // Logic for loading the page
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            Products.Add(NewProduct);
            // Redirects to the GET handler to refresh the list
            return RedirectToPage();
        }
    }
}