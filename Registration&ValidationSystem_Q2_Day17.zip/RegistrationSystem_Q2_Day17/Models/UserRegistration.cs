using System.ComponentModel.DataAnnotations;

namespace RegistrationSystem.Models
{
    public class UserRegistration
    {
        [Required(ErrorMessage = "Username is required")]
        public required string Username { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")] 
        public required string Email { get; set; }

        [Required(ErrorMessage = "Password is required")] 
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters")] 
        [DataType(DataType.Password)]
        public required string Password { get; set; }

        [Required(ErrorMessage = "Please confirm your password")] 
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords do not match")] 
        public required string ConfirmPassword { get; set; }
    }
}