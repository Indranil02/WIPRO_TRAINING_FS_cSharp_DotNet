using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    public class Book
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public int GenreId { get; set; }

        // Navigation Property: One-to-Many
        [ForeignKey("GenreId")]
        public Genre? Genre { get; set; }

        // Navigation Property: Many-to-Many join entity
        public ICollection<BookAuthor> BookAuthors { get; set; } = new List<BookAuthor>();
    }
}