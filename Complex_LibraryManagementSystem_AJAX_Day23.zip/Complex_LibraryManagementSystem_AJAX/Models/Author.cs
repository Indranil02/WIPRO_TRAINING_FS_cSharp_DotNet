using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class Author
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(150)]
        public string Name { get; set; } = string.Empty;

        // Navigation Property: Many-to-Many relationship configuration via join entity
        public ICollection<BookAuthor> BookAuthors { get; set; } = new List<BookAuthor>();
    }
}