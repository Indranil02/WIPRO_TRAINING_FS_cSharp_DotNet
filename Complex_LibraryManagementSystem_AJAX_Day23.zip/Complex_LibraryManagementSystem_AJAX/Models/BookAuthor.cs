namespace LibraryManagementSystem.Models
{
    // Explicit join entity to robustly handle the relationship in EF Core
    public class BookAuthor
    {
        public int BookId { get; set; }
        public Book? Book { get; set; }

        public int AuthorId { get; set; }
        public Author? Author { get; set; }
    }
}