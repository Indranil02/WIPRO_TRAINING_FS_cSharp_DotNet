using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories.Abstract
{
    // Task 4: Advanced query optimization interface definitions
    public interface IBookRepository : IRepository<Book>
    {
        // Eager loading, advanced filtering, and sorting bundled together
        Task<IEnumerable<Book>> GetOptimizedBooksAsync(string? filterText, int pageNumber, int pageSize);
    }
}