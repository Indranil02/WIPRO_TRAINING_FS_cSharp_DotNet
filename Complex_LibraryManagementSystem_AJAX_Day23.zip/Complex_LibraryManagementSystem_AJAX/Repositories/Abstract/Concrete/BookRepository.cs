using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Abstract;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Repositories.Concrete
{
    public class BookRepository : Repository<Book>, IBookRepository
    {
        public BookRepository(LibraryDbContext context) : base(context) { }

        // Advanced Query Optimization: Eager loading, pagination, and text filtering combined
        public async Task<IEnumerable<Book>> GetOptimizedBooksAsync(string? filterText, int pageNumber, int pageSize)
        {
            IQueryable<Book> query = _dbSet
                .Include(b => b.Genre)
                .Include(b => b.BookAuthors)
                    .ThenInclude(ba => ba.Author)
                .AsNoTracking(); // Optimization: Disables tracking for read-only query speed performance

            // Advanced Filtering
            if (!string.IsNullOrWhiteSpace(filterText))
            {
                query = query.Where(b => b.Title.Contains(filterText) || 
                                         (b.Genre != null && b.Genre.Name.Contains(filterText)));
            }

            // Advanced Sorting & Pagination
            return await query
                .OrderBy(b => b.Title)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }
    }
}