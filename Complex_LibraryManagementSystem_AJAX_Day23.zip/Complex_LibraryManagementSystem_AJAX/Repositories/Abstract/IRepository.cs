using System.Linq.Expressions;

namespace LibraryManagementSystem.Repositories.Abstract
{
    // Task 1: Generic repository interface managing standard CRUD operations asynchronously
    public interface IRepository<T> where T : class
    {
        Task<T?> GetByIdAsync(int id);
        Task<IEnumerable<T>> GetAllAsync();
        Task AddAsync(T entity);
        void Update(T entity); // EF Tracking handles update state locally
        void Delete(T entity);
        Task<bool> SaveChangesAsync();
    }
}