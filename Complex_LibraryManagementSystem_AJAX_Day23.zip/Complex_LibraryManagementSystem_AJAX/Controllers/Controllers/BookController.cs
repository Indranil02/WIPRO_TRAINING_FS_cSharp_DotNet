using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{
    public class BookController : Controller
    {
        private readonly IBookRepository _bookRepository;

        public BookController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        // Render Page View
        public IActionResult Index() => View();

        // AJAX: Advanced Query endpoint with Filtering and Pagination
        [HttpGet]
        public async Task<IActionResult> GetBooksJson(string? search, int page = 1, int size = 10)
        {
            try
            {
                var books = await _bookRepository.GetOptimizedBooksAsync(search, page, size);
                
                // Map to clean JSON response array structure
                var result = books.Select(b => new {
                    b.Id,
                    b.Title,
                    Genre = b.Genre?.Name ?? "N/A",
                    Authors = string.Join(", ", b.BookAuthors.Select(ba => ba.Author?.Name))
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                // Task 4: Robust backend server-side exception handling
                return Json(new { success = false, message = "Error fetching records: " + ex.Message });
            }
        }

        // AJAX: Asynchronous handling for Adding/Updating items
        [HttpPost]
        public async Task<IActionResult> SaveBookJson([FromBody] Book model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return Json(new { success = false, message = "Invalid data models submitted." });

                if (model.Id == 0)
                {
                    await _bookRepository.AddAsync(model);
                }
                else
                {
                    _bookRepository.Update(model);
                }

                await _bookRepository.SaveChangesAsync();
                return Json(new { success = true, message = "Book entry updated/created successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "An internal error occurred: " + ex.Message });
            }
        }

        // AJAX: Async record deletion
        [HttpPost]
        public async Task<IActionResult> DeleteBookJson(int id)
        {
            try
            {
                var book = await _bookRepository.GetByIdAsync(id);
                if (book == null) 
                    return Json(new { success = false, message = "Book record details not found." });

                _bookRepository.Delete(book);
                await _bookRepository.SaveChangesAsync();

                return Json(new { success = true, message = "Record successfully omitted." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Could not delete record: " + ex.Message });
            }
        }
    }
}