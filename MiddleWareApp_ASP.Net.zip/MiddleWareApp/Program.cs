var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// 1. Custom Logging Middleware (User Story 1 & 2)
app.Use(async (context, next) => {
    // Log the incoming request
    Console.WriteLine($"Incoming: {context.Request.Method} {context.Request.Path}");
    await next();
    // Log the outgoing response
    Console.WriteLine($"Outgoing: {context.Response.StatusCode}");
});

// 2. Security: HTTPS & CSP (User Story 4)
app.UseHttpsRedirection(); // Enforce HTTPS
app.Use(async (context, next) => {
    context.Response.Headers.Append("Content-Security-Policy", "default-src 'self';"); // XSS Mitigation
    await next();
});

// 3. Serve Static Files (User Story 3)
app.UseStaticFiles(); // Enables serving from wwwroot[cite: 1]

app.MapGet("/", () => Results.Redirect("/index.html"));

app.Run();