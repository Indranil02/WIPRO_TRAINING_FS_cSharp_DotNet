javascript
    console.log("Static file loaded successfully!");
    alert("Middleware is serving this file!");