using Microsoft.AspNetCore.Mvc;
using BookstoreApp.Models;
using BookstoreApp.Repositories;
using System.Data;

namespace BookstoreApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly BookRepository _repository;

        public BookController(IConfiguration configuration)
        {
            _repository = new BookRepository(configuration);
        }

        [HttpGet("connected")]
        public IActionResult GetBooksConnected()
        {
            var books = _repository.GetAllBooksConnected();
            return Ok(books);
        }

        [HttpGet("disconnected")]
        public IActionResult GetBooksDisconnected()
        {
            var ds = _repository.GetAllBooksDisconnected();
            // Convert DataTable back to a list to return as JSON
            var books = new List<Book>();
            foreach (DataRow row in ds.Tables["Books"]!.Rows)
            {
                books.Add(new Book
                {
                    Id = Convert.ToInt32(row["Id"]),
                    Title = row["Title"].ToString()!,
                    Author = row["Author"].ToString()!,
                    Price = Convert.ToDecimal(row["Price"])
                });
            }
            return Ok(books);
        }

        [HttpPost]
        public IActionResult AddBook([FromBody] Book book)
        {
            _repository.AddBook(book);
            return Ok("Book added securely using Stored Procedure.");
        }

        [HttpPut]
        public IActionResult UpdateBook([FromBody] Book book)
        {
            _repository.UpdateBook(book);
            return Ok("Book updated successfully.");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            _repository.DeleteBook(id);
            return Ok("Book deleted successfully.");
        }

        [HttpPost("simulate-dataset-update")]
        public IActionResult SimulateDataSetUpdate()
        {
            _repository.UpdateDatabaseFromDataSet();
            return Ok("Database updated using SqlDataAdapter from a disconnected DataTable.");
        }
    }
}