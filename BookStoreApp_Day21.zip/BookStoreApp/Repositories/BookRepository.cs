using Microsoft.Data.SqlClient;
using System.Data;
using BookstoreApp.Models;

namespace BookstoreApp.Repositories
{
    public class BookRepository
    {
        private readonly string _connectionString;

        public BookRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection") 
                ?? throw new InvalidOperationException("Connection string not found.");
        }

        // USER STORY 1 & 5: Read data using SqlDataReader (Connected Architecture)
        public List<Book> GetAllBooksConnected()
        {
            var books = new List<Book>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "SELECT Id, Title, Author, Price FROM Books";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                books.Add(new Book
                                {
                                    Id = reader.GetInt32(0),
                                    Title = reader.GetString(1),
                                    Author = reader.GetString(2),
                                    Price = reader.GetDecimal(3)
                                });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // Proper error handling/logging should be implemented here
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                }
            }
            return books;
        }

        // USER STORY 4 & 5: Read data using SqlDataAdapter and DataSet (Disconnected Architecture)
        public DataSet GetAllBooksDisconnected()
        {
            DataSet ds = new DataSet();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "SELECT Id, Title, Author, Price FROM Books";
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                {
                    try
                    {
                        // Fills the DataSet without keeping the connection open
                        adapter.Fill(ds, "Books");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                }
            }
            return ds;
        }

        // USER STORY 2 & 3: Add using Stored Procedure and Parameterized Queries to prevent SQL Injection
        public void AddBook(Book book)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_AddBook", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Parameterized queries protect against SQL injection
                    cmd.Parameters.AddWithValue("@Title", book.Title);
                    cmd.Parameters.AddWithValue("@Author", book.Author);
                    cmd.Parameters.AddWithValue("@Price", book.Price);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // USER STORY 3: Update using Stored Procedure
        public void UpdateBook(Book book)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_UpdateBook", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", book.Id);
                    cmd.Parameters.AddWithValue("@Title", book.Title);
                    cmd.Parameters.AddWithValue("@Author", book.Author);
                    cmd.Parameters.AddWithValue("@Price", book.Price);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // USER STORY 3: Delete using Stored Procedure
        public void DeleteBook(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_DeleteBook", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // USER STORY 4: Updating database via changes made to a DataTable
        public void UpdateDatabaseFromDataSet()
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "SELECT Id, Title, Author, Price FROM Books";
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                {
                    // Automatically generates insert/update/delete commands
                    SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "Books");

                    // Simulating a disconnected update: Add a new row to the DataTable offline
                    DataTable dt = ds.Tables["Books"]!;
                    DataRow newRow = dt.NewRow();
                    newRow["Title"] = "Disconnected Architecture Guide";
                    newRow["Author"] = "Jane Doe";
                    newRow["Price"] = 29.99m;
                    dt.Rows.Add(newRow);

                    // Push changes back to the database
                    adapter.Update(ds, "Books");
                }
            }
        }
    }
}