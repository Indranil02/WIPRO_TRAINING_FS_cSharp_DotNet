using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SecureNotesAPI.Data;
using SecureNotesAPI.Models;
using System.Security.Claims;

namespace SecureNotesAPI.Controllers
{
    [ApiController]
    [Route("api/notes")]
    [Authorize]
    public class NotesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public NotesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult AddNote(Note note)
        {
            var userIdClaim = User.FindFirst("UserId");

            if (userIdClaim == null)
                return Unauthorized();

            var userId = int.Parse(userIdClaim.Value);

            note.UserId = userId;

            _context.Notes.Add(note);
            _context.SaveChanges();

            return Ok(new
            {
                message = "Note added successfully.",
                noteId = note.Id
            });
        }

        [HttpGet]
        public IActionResult GetNotes()
        {
            var userIdClaim = User.FindFirst("UserId");

            if (userIdClaim == null)
                return Unauthorized();

            var userId = int.Parse(userIdClaim.Value);

            return Ok(
                _context.Notes
                .Where(n => n.UserId == userId)
                .ToList());
        }

        [HttpPut("{id}")]
        public IActionResult UpdateNote(int id, Note updated)
        {
            var note = _context.Notes.Find(id);

            if (note == null)
                return NotFound();

            note.Title = updated.Title;
            note.Content = updated.Content;

            _context.SaveChanges();

            return Ok(note);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNote(int id)
        {
            var note = _context.Notes.Find(id);

            if (note == null)
                return NotFound();

            _context.Notes.Remove(note);
            _context.SaveChanges();

            return Ok(new
            {
                message = "Note deleted successfully."
            });
        }
    }
}