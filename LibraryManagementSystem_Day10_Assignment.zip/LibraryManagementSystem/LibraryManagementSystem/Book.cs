﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryManagementSystem
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public bool IsBorrowed { get; private set; } // [cite: 52]

        public Book(string title, string author, string isbn)
        {
            Title = title;
            Author = author;
            ISBN = isbn;
            IsBorrowed = false;
        }

        public void Borrow() => IsBorrowed = true; // [cite: 52, 34]
        public void Return() => IsBorrowed = false; // [cite: 52, 40]
    }
}
