﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryManagementSystem
{
    public class Borrower
    {
        public string Name { get; set; }
        public string LibraryCardNumber { get; set; }
        public List<Book> BorrowedBooks { get; set; } = new List<Book>(); // [cite: 54]

        public Borrower(string name, string cardNumber)
        {
            Name = name;
            LibraryCardNumber = cardNumber;
        }

        public void BorrowBook(Book book) => BorrowedBooks.Add(book); // [cite: 54, 35]
        public void ReturnBook(Book book) => BorrowedBooks.Remove(book); // [cite: 54, 42]
    }
}
