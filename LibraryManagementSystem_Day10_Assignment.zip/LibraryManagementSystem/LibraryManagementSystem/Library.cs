﻿using LibraryManagementSystem;

public class Library
{
    public List<Book> Books { get; set; } = new List<Book>(); // [cite: 56]
    public List<Borrower> Borrowers { get; set; } = new List<Borrower>(); // [cite: 56]

    public void AddBook(Book book) // [cite: 56]
    {
        Books.Add(book);
        Console.WriteLine($"Book '{book.Title}' added successfully."); // [cite: 20]
    }

    public void RegisterBorrower(Borrower borrower) // [cite: 56]
    {
        Borrowers.Add(borrower);
        Console.WriteLine($"Borrower '{borrower.Name}' registered successfully."); // [cite: 26]
    }

    public void BorrowBook(string isbn, string libraryCardNumber) // [cite: 56]
    {
        var book = Books.FirstOrDefault(b => b.ISBN == isbn && !b.IsBorrowed);
        var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == libraryCardNumber);

        if (book != null && borrower != null)
        {
            book.Borrow();
            borrower.BorrowBook(book);
        }
    }

    public void ReturnBook(string isbn, string libraryCardNumber) // [cite: 58]
    {
        var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == libraryCardNumber);
        var book = borrower?.BorrowedBooks.FirstOrDefault(b => b.ISBN == isbn);

        if (book != null)
        {
            book.Return();
            borrower.ReturnBook(book);
        }
    }

    public void ViewBooks() // [cite: 58]
    {
        foreach (var b in Books)
            Console.WriteLine($"{b.Title} (ISBN: {b.ISBN}) - Status: {(b.IsBorrowed ? "Borrowed" : "Available")}"); // [cite: 46]
    }

    public void ViewBorrowers() // [cite: 58]
    {
        foreach (var br in Borrowers)
            Console.WriteLine($"{br.Name} (ID: {br.LibraryCardNumber}) - Books: {br.BorrowedBooks.Count}"); // [cite: 47]
    }
}