﻿using LibraryManagementSystem;
using NUnit.Framework;

[TestFixture]
public class LibraryTests
{
    private Library _library;

    [SetUp]
    public void Setup() => _library = new Library();

    [Test]
   
    public void AddBook_ShouldAddToList()
    {
        var book = new Book("C# Basics", "John Doe", "123");
        _library.AddBook(book);
        Assert.AreEqual(1, _library.Books.Count);
    }

    [Test]
   
    public void BorrowBook_ShouldMarkAsBorrowedAndAssignToBorrower()
    {
        var book = new Book("C# Basics", "John Doe", "123");
        var borrower = new Borrower("Alice", "B01");
        _library.AddBook(book);
        _library.RegisterBorrower(borrower);

        _library.BorrowBook("123", "B01");

        Assert.IsTrue(book.IsBorrowed);
        Assert.Contains(book, borrower.BorrowedBooks);
    }

    [Test]
    public void ReturnBook_ShouldMakeAvailableAndRemoveFromBorrower() // [cite: 71, 72]
    {
        var book = new Book("C# Basics", "John Doe", "123");
        var borrower = new Borrower("Alice", "B01");
        _library.AddBook(book);
        _library.RegisterBorrower(borrower);
        _library.BorrowBook("123", "B01");

        _library.ReturnBook("123", "B01");

        Assert.IsFalse(book.IsBorrowed);
        Assert.IsEmpty(borrower.BorrowedBooks);
    }
}