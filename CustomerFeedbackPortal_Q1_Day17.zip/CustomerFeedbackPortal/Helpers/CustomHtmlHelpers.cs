using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CustomerFeedbackPortal.Helpers
{
    public static class CustomHtmlHelpers
    {
        public static IHtmlContent StyledInput(this IHtmlHelper htmlHelper, string name, string placeholder, string cssClass)
        {
            // 1. Create an 'input' tag
            var input = new TagBuilder("input");

            input.Attributes.Add("type", "text");
            input.Attributes.Add("name", name);
            input.Attributes.Add("placeholder", placeholder);
            input.Attributes.Add("class", cssClass);

            // 3. Return the HTML content
            return input;
        }
    }
}