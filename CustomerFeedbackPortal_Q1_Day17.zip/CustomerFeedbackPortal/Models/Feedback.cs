namespace CustomerFeedbackPortal.Models
{
    public class Feedback
    {
        public required string Name { get; set; }
        public required string Email { get; set; }
        public int Rating { get; set; }
        public required string Comments { get; set; }
    }
}