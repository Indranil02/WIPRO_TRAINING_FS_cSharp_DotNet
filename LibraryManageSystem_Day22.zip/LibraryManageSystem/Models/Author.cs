namespace LibraryManagementSystem.Models
{
    public class Author
    {
        public int AuthorId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Bio { get; set; } = string.Empty;

        // Navigation property
        public ICollection<Book> Books { get; set; } = new List<Book>();
    }
}