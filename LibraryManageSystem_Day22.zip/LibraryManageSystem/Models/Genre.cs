namespace LibraryManagementSystem.Models
{
    public class Genre
    {
        public int GenreId { get; set; }
        public string Name { get; set; } = string.Empty;

        // Navigation property for many-to-many
        public ICollection<Book> Books { get; set; } = new List<Book>();
    }
}