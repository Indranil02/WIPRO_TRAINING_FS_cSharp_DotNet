namespace LibraryManagementSystem.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; } = string.Empty;

        // Foreign Key
        public int AuthorId { get; set; }
        
        // Navigation properties
        public Author? Author { get; set; }
        public ICollection<Genre> Genres { get; set; } = new List<Genre>();
    }
}