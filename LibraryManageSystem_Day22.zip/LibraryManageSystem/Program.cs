using LibraryManagementSystem.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1. ADD SERVICES (Must be before builder.Build())
builder.Services.AddControllers();

// These two lines register Swagger services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(); 

// This line registers your database context
builder.Services.AddDbContext<LibraryContext>(options =>
    options.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=LibraryDb;Trusted_Connection=True;MultipleActiveResultSets=true"));


// 2. BUILD THE APPLICATION
var app = builder.Build();


// 3. CONFIGURE THE PIPELINE (Must be after builder.Build())
// These lines turn on the Swagger user interface in development mode
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
    
// This maps your BooksController endpoints so they can be reached
app.MapControllers();

app.Run();